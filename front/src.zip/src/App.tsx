import React from 'react';
import Router from './router/router';
import NavBar from './components/navbar/navbar'
import Link from './types/link';
interface AppProps{

}
interface AppState{

}

const MOCK_LINK_LIST : Link[] = [
  {
    name : "Accueil",
    path : "/"
  },
  {
    name : "Informations",
    path : "/informations"
  }
]
/**
 * Composant affichant le cadre de l'application
 */
export default class App extends React.Component<AppProps, AppState> {
  constructor(props:AppProps){
    super(props)
    this.state = {

    }
  }
  render(){
    return (
      <div data-testid="app" className="App">
        <NavBar links={MOCK_LINK_LIST}/>
        <Router/>
      </div>
    );
  }
}
