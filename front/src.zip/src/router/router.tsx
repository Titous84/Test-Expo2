import React from 'react';
import {Route, Routes} from "react-router-dom"
import NotFound from '../pages/404/notfound';
import { createRandomKey } from '../utils/utils';
import { pages } from './routes';

interface RouterProps{

}
interface RouterState{

}
/**
 * Classe gérant le routage de l'application.\
 * Prend l'URL et affiche la bonne page.
 */
export default class Router extends React.Component<RouterProps, RouterState> {
    constructor(props:RouterProps){
        super(props)
        this.state = {
            
        }
    }
    /**
     * Génère les toutes de l'application à l'aide de la liste de routes du fichier `routes.ts`
     * @returns Les routes principales de l'application
     */
    renderRoutes(){
        return pages.map(page => {
            return <Route path={page.path} key={createRandomKey()} element={<page.element/>} />
        })
    }
    render(){
        return (
            <Routes key={createRandomKey()}>
                {this.renderRoutes()}
                <Route path="*" element={<NotFound />} key={createRandomKey()}/>
            </Routes>
        );
    }
}