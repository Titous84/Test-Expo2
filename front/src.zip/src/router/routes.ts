import HomePage from "../pages/Home/homepage";
import PageConnexion from "../pages/Connexion/pageconnexion";

export interface Path{
    path:string;
    name:string;
    element?:any;
}
/**
 * Liste des pages principales du site
 */
export const pages : Path[] = [
    {path:"/",name:"Accueil",element:HomePage},
    {path:"/connexion",name:"Connexion",element:PageConnexion}
]