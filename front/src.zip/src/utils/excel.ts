import * as FileSaver from "file-saver";
import * as XLSX from "xlsx";

const defaultSheetName = "Données"
const fileType =
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
// Excel file extension
const fileExtension = ".xlsx";

/**
 * Interface représentant une colonne à exporter.
 * @example
 * const items = [{id:2,name:"Test"}]
 * //Colonne pour le champ « id »
 * const columnID = {key:"id",title:"Identifiant"}
 */
export interface Column{
    /**
     * Clé du JSON.
     */
    key:string;
    /**
     * Titre à afficher dans l'Excel pour le nom de la colonne.
     */
    title:String;
}
/**
 * Convertir un tableau de JSON en tableau de tableaux. 
 * @param data Tableau d'objets
 * @param columns Colonnes à inclure
 */
export function jsonArrayToAOA<T>(data:T[],columns:Column[]) : any[][]{
    let arrayOfArray : any[][] = []
    //Crée un tableau contenant tous les titres
    const titles = columns.map(column => {
        return column.title
    })
    //Insérer les titres dans le tableau de tableaux
    arrayOfArray.push(titles);

    //Pousse chaque objet avec les clés désirées dans le tableau de tableaux
    data.forEach((item : any) => {
        arrayOfArray.push(
            columns.map(column => {
                return item[column.key]
            })
        )
    })

    return arrayOfArray
}

/**
 * Exporter des données dans un fichier Excel (.xlsx)
 * @param data Données à exporter
 * @param columns Colonnes à exporter
 * @param fileName Nom du fichier à générer
 * @param sheetName Nom de la feuille à générer (facultatif)
 */
export function exportToExcel<T>(data:T[],columns:Column[], fileName : string, sheetName?:string) : void {
    let arrayOfArray = jsonArrayToAOA(data,columns);
    //Crée une feuille Excel avec le tableau de tableaux
    const workSheet = XLSX.utils.aoa_to_sheet(arrayOfArray);
    //Nom de la feuille à créer (Si aucun, donner le nom par défaut)
    if (!sheetName) sheetName = defaultSheetName;
    //Crée un livre de feuilles incluant la feuille créée
    const workBook = {
        Sheets: { data: workSheet, cols: [] },
        SheetNames: [sheetName],
    };
    // Exporte le Excel avec le nom désiré et l'extension du fichier
    const excelBuffer = XLSX.write(workBook, { bookType: "xlsx", type: "array" });
    const fileData = new Blob([excelBuffer], { type: fileType });
    FileSaver.saveAs(fileData, fileName + fileExtension);
}
