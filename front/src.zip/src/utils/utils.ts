import {v4 as uuidv4} from 'uuid';

/**
 * Crée une clé unique.
 * @example
 * list.map(item => {
 *     return <h1 key={createRandomKey()}></h1>
 * })
 * @returns Clé unique
 */
export function createRandomKey(){
    return uuidv4();
}

/**
 * Vérification de l'égalité entre deux tableaux de tableaux.
 * @param a Premier tableau de tableaux à tester.
 * @param b Deuxième tableau de tableaux à tester.
 * @returns Vrai -> Égaux, Faux -> Inégaux
 */
export function AOATester(a:any[][],b:any[][]){
    for (let i = 0; i < a.length; i++) {
        for (let j = 0; j < a[i].length; j++) {
            if (a[i][j] !== b[i][j]){
                return false;
            }
        }
    }
    return true;
}
