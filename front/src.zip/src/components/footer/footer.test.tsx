import React from 'react';
import { render, screen } from '@testing-library/react';
import Footer from './footer';

test('renders footer', async () => {
  render(<Footer />);
  const linkElement = await screen.findAllByTestId("footer");
  expect(linkElement.length === 1).toBeTruthy()
});
