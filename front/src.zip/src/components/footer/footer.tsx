import React from 'react';

interface FooterProps{

}
interface FooterState{

}
/**
 * Pied de page de l'application
 */
export default class Footer extends React.Component<FooterProps, FooterState> {
    constructor(props:FooterProps){
        super(props)
        this.state = {
            
        }
    }
    render(){
        return (
        <div data-testid="footer">
            <p>
                ExpoSAT pied de page
            </p>
        </div>
        );
    }
}