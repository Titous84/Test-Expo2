import React from 'react';

interface LoginProps{

}
interface LoginState{

}

export default class Login extends React.Component<LoginProps, LoginState> {
    constructor(props:LoginProps){
        super(props)
        this.state = {
            
        }
    }
    render(){
        return (
            <>
            </>
        );
    }
}