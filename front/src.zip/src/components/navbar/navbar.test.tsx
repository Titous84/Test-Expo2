import React from 'react';
import { render, screen } from '@testing-library/react';
import NavBar from './navbar';
import Link from '../../types/link';

const MOCK_LINK_LIST : Link[] = [
  {
    name : "Accueil",
    path : "/"
  },
  {
    name : "Informations",
    path : "/informations"
  }
]

test('renders navbar', async () => {
  render(<NavBar links={MOCK_LINK_LIST}/>);
  const linkElement = await screen.findAllByTestId("navbar");
  expect(linkElement.length === 1).toBeTruthy()
});
