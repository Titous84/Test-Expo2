import React from 'react';
import styles from './navbar.module.css'
import Hamburger from './hamburger'
import { Path } from '../../router/routes'
import { Link } from 'react-router-dom'

interface NavBarProps{
    links: Path[]
}
interface NavBarState{

}

/**
 * Barre de navigation de l'application
 */

export default class NavBar extends React.Component<NavBarProps, NavBarState> {
    constructor(props:NavBarProps){
        super(props)
        this.state = {
            links : []
        }
    }
    generateLinks() {
        return this.props.links.map(link=>{
            return <li key={link.path} className={styles.positionGauche}><Link to={link.path} className={styles.lienMenu}>{link.name}</Link></li>;
        })
     }
    /*
     * Contient une liste des elements dans la barre menu,
     * Le contenu change en fonction de la resolution
     */
    render(){
        const liensPossibles = this.props.links
        return (
            <div data-testid="navbar" className={styles.backgroundElements + " " + styles.block}>
                <li className={styles.positionGauche}> <a href="/">
                            <img src={require('./LOGO EXPOSAT_2022.png')} alt="Logo du Cégep de Victoriaville" 
                            className={styles.logoCegep}>
                            </img></a></li>
                <div className={styles.menuGlobal}>
                    <ul className={styles.backgroundElements}>
                        {this.generateLinks()}
                    </ul>
                </div>
                <div className={styles.hamburger}>
                    <li className={styles.positionDroit}><Hamburger links={liensPossibles}/></li>
                </div>
            </div>
        );
    }
}