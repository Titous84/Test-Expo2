import React from 'react';

export interface PageProps{

}
/**
 * Classe parent des pages principales.
 */
export default class Page<Type> extends React.Component<PageProps, Type> {
    render() {
        return <></>;
      }
}