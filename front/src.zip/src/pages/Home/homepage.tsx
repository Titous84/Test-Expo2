import Page, { PageProps } from "../page-template";
import styles from "./homepage.module.css"
/**
 * Page d'accueil
 */
export default class HomePage extends Page<{}> {
    constructor(props:PageProps){
        super(props)

        this.state = {

        }
    }
    public render() {
        return (
            <div data-testid="homepage">
                <h1 className={styles.titre}>Accueil</h1>
            </div>
        )
    }
}