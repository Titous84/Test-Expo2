import React from 'react';
import { render, screen } from '@testing-library/react';
import HomePage from './homepage';

test('renders home page', async () => {
  render(<HomePage />);
  const linkElement = await screen.findAllByTestId("homepage");
  expect(linkElement.length === 1).toBeTruthy()
});
