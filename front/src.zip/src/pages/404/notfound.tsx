import React from 'react';

interface NotFoundProps{

}
interface NotFoundState{

}
/**
 * Page 404
 */
export default class NotFound extends React.Component<NotFoundProps, NotFoundState> {
    constructor(props:NotFoundProps){
        super(props)
        this.state = {
            
        }
    }
    render(){
        return (
            <>
            <h1 data-testid="404">404 - La page n'a pas été trouvé</h1>
            </>
        );
    }
}