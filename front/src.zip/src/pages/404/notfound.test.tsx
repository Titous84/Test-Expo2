import React from 'react';
import { render, screen } from '@testing-library/react';
import NotFound from './notfound';

test('renders learn react link', async () => {
  render(<NotFound />);
  const linkElement = await screen.findAllByTestId("404");
  expect(linkElement.length === 1).toBeTruthy()
});
