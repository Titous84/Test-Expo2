import Page, { PageProps } from "../page-template";
import React from 'react';
import Button from '@mui/material/Button';
import { ValidatorForm, TextValidator } from 'react-material-ui-form-validator';
import styles from "./pageconnexion.module.css"

interface ConnectionPageState{
    username: string,
    password: string

}

/**
 * Page de connexion
 */

export default class PageConnexion extends Page<ConnectionPageState> {
    constructor(props:PageProps){
        super(props)

        //Garde les informations
        this.state = {
            username: '',
            password: ''
        }
    }

    //event: any changé pour React.ChangeEvent<any>
    handleChangeNomUtilisateur = (event: React.ChangeEvent<any>) => {
        const nomutilisateur = event.target.value;
        this.setState({ username : nomutilisateur });
    }

    //event: any changé pour React.ChangeEvent<any>
    handleChangeMotDePasse = (event: React.ChangeEvent<any>) => {
        const motdepasse = event.target.value;
        this.setState({ password : motdepasse });
    }

    handleSubmit = () => {
        // your submit logic
        alert('You have submitted the form.')
    }

    public render() {

        /*
        *   Formulaire React
        *   https://www.npmjs.com/package/react-material-ui-form-validator
        */

        return (
            <div className={styles.toLeft}>
                <h2 className={styles.centrerTexte}>Me connecter</h2>
                <hr className={styles.gradientTransparent}></hr>
                <ValidatorForm
                ref="form"
                onSubmit={this.handleSubmit}
                onError={errors => console.log(errors)}
                className={styles.paddingFormulaire}
                >
                    <div className={styles.paddingFormulaire}>
                        <TextValidator
                            label="Nom utilisateur"
                            onChange={this.handleChangeNomUtilisateur}
                            name="nomutilisateur"
                            value={this.state.username}
                            validators={['required']}
                            errorMessages={['Le nom utilisateur est requis']}
                            className={styles.paddingFormulaire}
                        />
                    </div>
                    <div className={styles.paddingFormulaire}>
                        <TextValidator
                            label="Mot de passe"
                            onChange={this.handleChangeMotDePasse}
                            name="motdepasse"
                            type="password"
                            value={this.state.password}
                            validators={['required']}
                            errorMessages={['Le mot de passe est requis']}
                            className={styles.paddingFormulaire}
                        />
                    </div>
                    <div className={styles.paddingFormulaire}>
                        <Button type="submit" className={styles.boutonConnexion + ' ' + styles.boutonHover}>Connexion</Button>
                        <Button type="button" className={styles.titre}>Mot de passe oublié</Button>
                    </div>
                </ValidatorForm>
            </div>
        )
    }
    
}