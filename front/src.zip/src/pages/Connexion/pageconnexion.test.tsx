import React from 'react';
import { render, screen } from '@testing-library/react';
import PageConnexion from './pageconnexion';

test('renders home page', async () => {
  render(<PageConnexion />);
  const linkElement = await screen.findAllByTestId("pageconnexion");
  expect(linkElement.length === 1).toBeTruthy()
});
