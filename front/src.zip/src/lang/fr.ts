/**
 * Chaînes de caractères inclues dans le site.
 */
export const TEXTS = {
    homepage:{
        title:"Accueil",
    },
    signup:{
        title:"Inscription Expo Sat",
        email:{
            label:"Adresse courriel",
            error:{
                required:"L'adresse courriel est requis",
                invalide:"Le courriel est invalide",
                maximum:"Le maximum est de 255 caractères",
            }
        },
        name:{
            label:"Prénom",
            error:{
                required:"Le prénom est requis",
                maximum:"Le maximum est de 50 caractères",
            }
        },
        familyName:{
            label:"Nom famille",
            error:{
                required:"Le nom famille est requis",
                maximum:"Le maximum est de 50 caractères",
            }
        },
        information:{
            title:"Informations sur l'équipe",
            text:"En raison des consignes de la santé publique, la formule a dû être adaptée pour l'édition 2021. Afin de tenir compte des défis techniques d’une version virtuelle, la participation se limite aux programmes ayant Expo SAT à leur épreuve synthèse de programme. Les présentations seront également filmées et/ou enregistrées et transmises aux membres du personnel impliqués dans le processus d'évaluation.",
            titleStand:{
                label:"Titre du stand",
                error:{
                    required:"Le titre du stand est requis",
                    maximum:"Le maximum est de 30 caractères",
                },
                text:"Votre titre doit être accrocheur et original pour attirer l'attention des visiteurs. Faites preuve de créativité !",
            },
            descriptionStand:{
                label:"Description du stand",
                error:{
                    required:"La description du stand est requis",
                    maximum:"Le maximum est de 255 caractères",
                },
                text:"La description de votre stand doit être attrayante, précise et claire. Elle sera utilisée dans le dépliant remis aux visiteurs lors de leur arrivée à l'exposition.",
            },
            category:{
                label:"Catégorie",
                error:{
                    required:"Choisiser une catégorie"
                },
                help:"Reférez-vous au Guide de l'exposant pour savoir dans quelle catégorie vous inscrire."
            },
            schoolYear:{
                label:"Année d'étude",
                checkboxOne:"1<sup>re</sup> année",
                checkboxTwo:"2<sup>e</sup> ou 3<sup>e</sup> année",
                error:{
                    required:"Sélectionner une année d'étude"
                },
                help:"Dans le cas où les années diffèrent, le plus ancien l'emporte (2e-3e année)."
            },
            contactPerson:{
                label:"Coordonnées de la personne-ressource",
                firtsLastName:{
                    label:"Pénom et nom",
                    error:{
                        required:"Le prénom et le nom est requis",
                        maximum:"Le maximum est de 50 caratères"
                    }
                },
                email:{
                    label:"Adresse courriel",
                    error:{
                        required:"L'adresse courriel est requis",
                        maximum:"Le maximum est de 255 caratères'"
                    }
                },
                help:"La personne-ressource est l'enseignant(e) qui vous encadre dans votre projet."
            },
            buttonContactPerson:{
                label:"Ajouter une personne-ressource"
            }
        }
    }
}