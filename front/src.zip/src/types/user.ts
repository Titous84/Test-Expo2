/**
 * Interface représentant l'usager et ses informations.
 */
export default interface User {

}