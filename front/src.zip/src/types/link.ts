export default interface Link {
    name : string,
    path : string
}